st=input("")
print(st.lower())
