mass=int(input("m: "))
c=3*(10**8)
energy=mass*(c**2)
print(energy)
