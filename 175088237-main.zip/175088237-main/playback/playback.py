st=input("")
print(st.replace(" ","..."))
